package com.example.aula2604;

public class Nota {

    int id;
    String txt;

    public Nota(int id, String txt){
        this.id = id;
        this.txt = txt;
    }
}
