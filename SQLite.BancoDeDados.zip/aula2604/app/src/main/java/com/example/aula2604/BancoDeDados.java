package com.example.aula2604;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import java.sql.SQLData;

public class BancoDeDados extends AppCompatActivity {

    SQLiteDatabase sqLiteDatabase; //ate o WhatsApp utiliza um Banco de Dados de SQLite
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_banco_de_dados);
        sqLiteDatabase = openOrCreateDatabase("notas",MODE_PRIVATE, null);
        sqLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS notas(id INTEGER PRIMARY KEY AUTOINCREMENT, txt, TEXT);");

        String msg = "Hello";

        //JEITO MAIS LIXO QUE TEM PARA FAZER
       // sqLiteDatabase.execSQL("INSERT INTO NOTAS(id, txt) VALUES(1, 'GABI');"   );

        ContentValues contentValues = new ContentValues();
       //contentValues.put("id", 1);
        contentValues.put("txt", "Ola Mundão");

        sqLiteDatabase.insert("notas", null, contentValues);

    }
}